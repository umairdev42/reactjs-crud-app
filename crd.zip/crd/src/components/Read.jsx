import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

function Read() {

  const [apiData, setApiData] = useState([])

  function getData() {
    axios.get('https://668f9eebc0a7969efd98ad73.mockapi.io/reac-crud')
      .then((response) => {
        setApiData(response.data)
      })
  }


  useEffect(() => {
    getData()
  }, [])



  return (
    <>
      <div className="create-btn">
        <Link to='/create'>
          <button>Create New Data</button>
        </Link>
      </div>

      <div className="tableContainer">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Age</th>
              <th>Email</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {
              apiData.map((item) => {
                return (
                  <tr key={item.id}>
                    <td>{item.id}</td>
                    <td>{item.name}</td>
                    <td>{item.age}</td>
                    <td>{item.email}</td>
                    <td>
                      <button>Update</button>
                    </td>
                    <td>
                      <button onClick={handleDelete}>Delete</button>
                    </td>
                  </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
    </>
  )
}

export default Read